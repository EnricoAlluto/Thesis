const express = require('express');
const cors = require('cors');
const axios = require('axios');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));

app.post('/proxy', async (req, res) => {
    try {
        const response = await axios.post(
            'http://fontanegli.spallared.it:8080/manudb/store.php',
            new URLSearchParams(req.body).toString(),
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }
        );

        res.status(200).send(response.data);
    } catch (error) {
        console.error('Errore nel proxy:', error.message);
        res.status(500).json({ error: 'Errore nel proxy', details: error.message });
    }
});

app.listen(PORT, () => {
    console.log(`Proxy server attivo su http://localhost:${PORT}`);
});
